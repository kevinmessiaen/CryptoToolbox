package com.messiaen.cryptotoolbox.feature;

import android.arch.persistence.room.Room;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.GsonBuilder;
import com.messiaen.cryptotoolbox.feature.cmc.dto.Cryptocurrency;
import com.messiaen.cryptotoolbox.feature.cmc.results.CryptocurrenciesMap;
import com.messiaen.cryptotoolbox.feature.cmc.services.CryptocurrenciesMapper;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import butterknife.BindString;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private CryptocurrenciesMapper cryptocurrencyMapService;

    private CryptoToolboxDatabase cryptoToolboxDatabase;

    @BindString(com.messiaen.cryptotoolbox.R.string.cmc_sandbox_api_key)
    String apiKey;

    @BindString(com.messiaen.cryptotoolbox.R.string.cmc_sandbox_url)
    String apiUrl;

    @BindString(com.messiaen.cryptotoolbox.R.string.database_name)
    String databaseName;

    @BindView(R.id.test_result)
    TextView testGetTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(apiUrl)
                .addConverterFactory(GsonConverterFactory.create(
                        new GsonBuilder()
                                .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssX")
                                .create()))
                .build();

        cryptocurrencyMapService = retrofit.create(CryptocurrenciesMapper.class);

        cryptoToolboxDatabase = Room.databaseBuilder(getApplicationContext(),
                CryptoToolboxDatabase.class, databaseName).build();

        List<Cryptocurrency> cryptocurrencies = cryptoToolboxDatabase.cryptocurrencyDao().findAll();

        if (cryptocurrencies != null)
            testGetTextView.setText(Arrays.toString(cryptocurrencies.toArray()));
    }

    @OnClick(R.id.test_get)
    public void onTestGet(View view) {
        cryptocurrencyMapService.mapCryptocurrencies(apiKey).enqueue(new Callback<CryptocurrenciesMap>() {
            @Override
            public void onResponse(Call<CryptocurrenciesMap> call, Response<CryptocurrenciesMap> response) {
                if (response.code() == 200) {
                    testGetTextView.setText(response.body().toString());
                    cryptoToolboxDatabase.cryptocurrencyDao().insertAll(response.body().getData().toArray(new Cryptocurrency[response.body().getData().size()]));
                } else {
                    try {
                        testGetTextView.setText("" + response.errorBody().string() + " - " + apiKey);
                    } catch (IOException e) {

                    }
                }
            }

            @Override
            public void onFailure(Call<CryptocurrenciesMap> call, Throwable t) {
                Log.e(MainActivity.class.getName(), "", t);
                testGetTextView.setText(t.getMessage());
            }
        });
    }
}
