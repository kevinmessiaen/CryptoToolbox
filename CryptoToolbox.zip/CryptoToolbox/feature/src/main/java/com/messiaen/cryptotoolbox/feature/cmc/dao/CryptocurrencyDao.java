package com.messiaen.cryptotoolbox.feature.cmc.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.messiaen.cryptotoolbox.feature.cmc.dto.Cryptocurrency;

import java.util.List;

@Dao
public interface CryptocurrencyDao {

    @Query("SELECT * FROM cryptocurrency")
    List<Cryptocurrency> findAll();

    @Query("SELECT * FROM cryptocurrency WHERE id = :id")
    Cryptocurrency findById(int id);

    @Insert
    void insertAll(Cryptocurrency... cryptocurrencies);

    @Update
    void update(Cryptocurrency cryptocurrency);

    @Delete
    void delete(Cryptocurrency cryptocurrency);

}
