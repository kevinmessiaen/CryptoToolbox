package com.messiaen.cryptotoolbox.feature.cmc.services;

import com.messiaen.cryptotoolbox.feature.cmc.results.CryptocurrenciesMap;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;

public interface CryptocurrenciesMapper {

    @GET("v1/cryptocurrency/map")
    Call<CryptocurrenciesMap> mapCryptocurrencies(@Header("X-CMC_PRO_API_KEY") String apiKey);
}
