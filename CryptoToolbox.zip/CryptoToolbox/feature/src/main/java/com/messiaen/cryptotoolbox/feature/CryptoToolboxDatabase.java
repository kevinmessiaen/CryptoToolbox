package com.messiaen.cryptotoolbox.feature;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;

import com.messiaen.cryptotoolbox.feature.cmc.dao.CryptocurrencyDao;
import com.messiaen.cryptotoolbox.feature.cmc.dto.Cryptocurrency;

@Database(entities = {Cryptocurrency.class}, version = 1)
public abstract class CryptoToolboxDatabase extends RoomDatabase {

    public abstract CryptocurrencyDao cryptocurrencyDao();

}
