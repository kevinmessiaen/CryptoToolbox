package com.messiaen.cryptotoolbox.feature.cmc.dto;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

import java.util.Date;

@Entity
public class Cryptocurrency {

    @PrimaryKey
    private int id;

    @ColumnInfo
    private String name;

    @ColumnInfo
    private String symbol;

    @ColumnInfo
    private String slug;

    @ColumnInfo(name = "is_active")
    private int isActive;

    @ColumnInfo(name = "first_historical_data")
    private Date firstHistoricalData;

    @ColumnInfo(name = "last_historical_data")
    private Date lastHistoricalData;

    @ColumnInfo
    private Cryptocurrency platform;

    public Cryptocurrency() {
    }

    public Cryptocurrency(int id, String name, String symbol, String slug, int isActive, Date firstHistoricalData, Date lastHistoricalData, Cryptocurrency platform) {
        this.id = id;
        this.name = name;
        this.symbol = symbol;
        this.slug = slug;
        this.isActive = isActive;
        this.firstHistoricalData = firstHistoricalData;
        this.lastHistoricalData = lastHistoricalData;
        this.platform = platform;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public int isActive() {
        return isActive;
    }

    public void setActive(int active) {
        isActive = active;
    }

    public Date getFirstHistoricalData() {
        return firstHistoricalData;
    }

    public void setFirstHistoricalData(Date firstHistoricalData) {
        this.firstHistoricalData = firstHistoricalData;
    }

    public Date getLastHistoricalData() {
        return lastHistoricalData;
    }

    public void setLastHistoricalData(Date lastHistoricalData) {
        this.lastHistoricalData = lastHistoricalData;
    }

    public Cryptocurrency getPlatform() {
        return platform;
    }

    public void setPlatform(Cryptocurrency platform) {
        this.platform = platform;
    }

    @Override
    public String toString() {
        return "Cryptocurrency{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", symbol='" + symbol + '\'' +
                ", slug='" + slug + '\'' +
                ", isActive=" + isActive +
                ", firstHistoricalData='" + firstHistoricalData + '\'' +
                ", lastHistoricalData='" + lastHistoricalData +
                ((platform != null) ? ('\'' + ", platform=" + platform) : "") +
                '}';
    }
}
