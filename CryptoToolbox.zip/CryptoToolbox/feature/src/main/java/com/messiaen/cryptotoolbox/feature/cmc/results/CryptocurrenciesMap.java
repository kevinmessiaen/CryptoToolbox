package com.messiaen.cryptotoolbox.feature.cmc.results;

import com.messiaen.cryptotoolbox.feature.cmc.dto.Cryptocurrency;
import com.messiaen.cryptotoolbox.feature.cmc.dto.Status;

import java.util.Arrays;
import java.util.List;

public class CryptocurrenciesMap {

    private List<Cryptocurrency> data;

    private Status status;

    public CryptocurrenciesMap() {
    }

    public CryptocurrenciesMap(List<Cryptocurrency> data, Status status) {
        this.data = data;
        this.status = status;
    }

    public List<Cryptocurrency> getData() {
        return data;
    }

    public void setData(List<Cryptocurrency> data) {
        this.data = data;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "CryptocurrenciesMap{" +
                ", status=" + status +
                "data=" + Arrays.toString(data.toArray()) +
                '}';
    }
}
